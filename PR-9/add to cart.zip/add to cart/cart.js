const cart = JSON.parse(localStorage.getItem(`cart`)) || [];

if (cart.length === 0) {
    document.getElementById(`add`).innerHTML = `
      <tr align="center" >
       <td colspan="4">your card is empty</td>
      </tr>
    `
}
else {
    document.getElementById(`add`).innerHTML = cart.map((item) =>
        `
        <tr>
        <td>${item.id}</td>
        <td>${item.name}</td>
        <td><img src="${item.img}" style="height:120px"></td>
        <td>${item.price}</td>
        </tr>
        `
    )
}